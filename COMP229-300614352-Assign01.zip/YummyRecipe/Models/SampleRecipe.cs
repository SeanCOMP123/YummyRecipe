﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace YummyRecipe.Models
{
    public class SampleRecipe
    {
        public string Name { get; set; }
        public string Main_Ingredient { get; set; }
        public int Durations {get; set; }
        public string Category { get; set; }
        public string Directions { get; set; }

    
    }
}
